// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evaluate flake outputs"); }
int main(){
  announce();
  return lionss_run_workload("flake_eval");
}
