// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Reflect HLSL bindings\n", stdout);
  return lionss_run_workload("hlsl_reflect");
}
