// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Count 31-mers\n", stdout);
  return lionss_run_workload("kmer-count31");
}
