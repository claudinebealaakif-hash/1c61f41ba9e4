// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Round-trip encode"); }
int main(){
  announce();
  return lionss_run_workload("serdetangent");
}
